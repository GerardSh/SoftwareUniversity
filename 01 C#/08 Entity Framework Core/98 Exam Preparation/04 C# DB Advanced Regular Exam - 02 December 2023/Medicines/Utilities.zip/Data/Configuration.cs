﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Medicines;User Id=sa;Password=r3F4iJbYas&#aRj^bmjj;TrustServerCertificate=true;";
    }
}
